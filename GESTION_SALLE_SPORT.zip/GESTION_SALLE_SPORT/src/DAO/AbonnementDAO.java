/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Entite.Abonnement;
import Interface.Dashboard;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author abdou-jabar
 */
@SuppressWarnings("unused")
public class AbonnementDAO {
    /**
     * Ajouter un nouvel abonnement
     */
    public static int ajouterAbonnement(Abonnement abonnement){
        int resultat = 0;
        
        Connection conn = Connexion.Connect();
        
        String requete = "INSERT INTO ABONNEMENT(ID_ABONNEMENT, LIBELLE, DUREE_MOIS, PRIX_MENSUEL) VALUES (?, ?, ?, ?);";
        
        PreparedStatement ps = null;

        try {
            ps = conn.prepareStatement(requete);
            ps.setString(1, abonnement.getId());
            ps.setString(2, abonnement.getLibelle());
            ps.setInt(3, abonnement.getDureeMois());
            ps.setFloat(4, abonnement.getPrixMensuel());
            resultat = ps.executeUpdate();
            ps.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(AbonnementDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return resultat;
    }
    
    /*
    Modifier un abonnement
    */
    public static int modifierAbonnement(Abonnement abonnement){
        int resultat = 0;
        
        Connection conn = Connexion.Connect();
        
        String requete = "UPDATE ABONNEMENT SET LIBELLE = ?, DUREE_MOIS = ?, PRIX_MENSUEL = ? WHERE ID_ABONNEMENT = ?;";
        
        PreparedStatement ps = null;
        
        try {
            ps = conn.prepareStatement(requete);
            ps.setString(1, abonnement.getLibelle());
            ps.setInt(2, abonnement.getDureeMois());
            ps.setFloat(3, abonnement.getPrixMensuel());
            ps.setString(4, abonnement.getId());
            resultat = ps.executeUpdate();
            ps.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(AbonnementDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return resultat;
    }
    
    /*
    Supprimer un abonnement
    */
    public static int supprimerAbonnement(Abonnement abonnement){
        int resultat = 0;
        
        Connection conn = Connexion.Connect();
        
        String requete = "DELETE FROM ABONNEMENT WHERE ID_ABONNEMENT = ?";
        
        PreparedStatement ps = null;
        
        try {
            ps = conn.prepareStatement(requete);
            ps.setString(1, abonnement.getId());
            resultat = ps.executeUpdate();
            ps.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(AbonnementDAO.class.getName()).log(Level.SEVERE, null, ex);
            Dashboard.chargerAbonnementsDansTable();
        }
        
        return resultat;
    }
    
    /*
    Liste de tous les abonnements
    */
    public static List<Abonnement> allAbonnement(){
        
        Connection conn = Connexion.Connect();
        
        List<Abonnement> abonnements = new ArrayList<>();
        
        String requete = "SELECT * FROM ABONNEMENT;";
        
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(requete);
            
            while(rs.next()){
                Abonnement abonnement = new Abonnement(
                        rs.getString("ID_ABONNEMENT"),
                        rs.getString("LIBELLE"),
                        rs.getInt("DUREE_MOIS"),
                        rs.getFloat("PRIX_MENSUEL")
                );
                abonnements.add(abonnement);
            }

         } catch (SQLException ex) {
            Logger.getLogger(AbonnementDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return abonnements;
    }
    
    /*
    Verifier si un ID est déjà présent dans la base de donnée
    */
    public static int verifierID(Abonnement abonnement){
        int resultat = 0;
        
        Connection conn  = Connexion.Connect();
        
        String requete = "SELECT ID_ABONNEMENT FROM ABONNEMENT WHERE ID_ABONNEMENT = ?";
        
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            ps = conn.prepareStatement(requete);
            ps.setString(1, abonnement.getId());
            rs = ps.executeQuery();
            if(rs.next()){
                resultat = 1;
            }
            ps.close();
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(AbonnementDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return resultat;
    }
    
    /*
        Récupérer le libelle de tous les abonnements
    */
    public static List<String> libelleAbonnements(){
        Connection conn = Connexion.Connect();
        
        List<String> libelle = new ArrayList<>();
        
        String requete = "SELECT LIBELLE FROM ABONNEMENT";
        
        Statement stmt = null;
        ResultSet rs = null;        
        
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(requete);
            
            while(rs.next()){
                libelle.add(rs.getString("LIBELLE"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(AbonnementDAO.class.getName()).log(Level.SEVERE, null, ex);            
        }
        return libelle;
    }
    
    public static String idDuLibelle(String libelle){

        String id = null;
        Connection conn = Connexion.Connect();

        String requete = "SELECT ID_ABONNEMENT FROM ABONNEMENT WHERE LIBELLE = ?;";

        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(requete);
            ps.setString(1, libelle);
            rs = ps.executeQuery();

            if(rs.next()){
                id = (rs.getString(1));
            }

        } catch (SQLException ex) {
            Logger.getLogger(SouscriptionDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    return id;
    }
}